package observer_pattern.firstStation;

/**
 * Created with IntelliJ IDEA.
 * User: guemseok.ju
 * Date: 13. 10. 31
 * Time: 오전 9:20
 * To change this template use File | Settings | File Templates.
 */
public interface Team_Master_Object {



    public  void doAction();




}
